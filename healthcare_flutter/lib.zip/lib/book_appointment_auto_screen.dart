import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'app_config.dart';

class BookAppointmentAutoScreen extends StatefulWidget {
  final String token;

  const BookAppointmentAutoScreen({super.key, required this.token});

  @override
  State<BookAppointmentAutoScreen> createState() =>
      _BookAppointmentAutoScreenState();
}

class _BookAppointmentAutoScreenState
    extends State<BookAppointmentAutoScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtl = TextEditingController();
  final _symptomCtl = TextEditingController();
  DateTime? _preferredDate;
  String? _preferredWindow; // MORNING / AFTERNOON / EVENING

  bool _submitting = false;

  @override
  void dispose() {
    _nameCtl.dispose();
    _symptomCtl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final pick = await showDatePicker(
      context: context,
      initialDate: _preferredDate ?? now.add(const Duration(days: 1)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 30)),
      helpText: 'Chọn ngày khám mong muốn',
    );
    if (pick != null) setState(() => _preferredDate = pick);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _submitting = true);

    final body = {
      "patient": {"fullName": _nameCtl.text.trim()},
      "symptom": _symptomCtl.text.trim(),
      "preferredDate": _preferredDate?.toIso8601String(),
      "preferredWindow": _preferredWindow
    };

    try {
      // Gọi AI backend (ẩn)
      final res = await http.post(
        Uri.parse('${AppConfig.ai}/auto-schedule'),
        headers: {
          'Authorization': 'Bearer ${widget.token}',
          'Content-Type': 'application/json'
        },
        body: jsonEncode(body),
      );

      if (res.statusCode == 200 || res.statusCode == 201) {
        // AI sẽ tự xếp bác sĩ/y tá và lưu vào DB
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("✅ Đăng ký thành công! Hệ thống đang sắp xếp lịch khám."),
          ),
        );
        _resetForm();
      } else {
        _showSnack("❌ Lỗi server: HTTP ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("❌ Không thể kết nối đến máy chủ: $e");
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _resetForm() {
    setState(() {
      _nameCtl.clear();
      _symptomCtl.clear();
      _preferredDate = null;
      _preferredWindow = null;
    });
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("🩺 Đăng ký khám bệnh")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Thông tin đăng ký khám",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              _buildTextField(
                controller: _nameCtl,
                label: "Họ và tên",
                icon: Icons.person_outline,
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? "Vui lòng nhập họ tên"
                    : null,
              ),
              const SizedBox(height: 12),

              _buildMultilineField(
                controller: _symptomCtl,
                label: "Triệu chứng / lý do khám",
                icon: Icons.sick_outlined,
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? "Vui lòng nhập triệu chứng"
                    : null,
              ),
              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: _pickDate,
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: "Ngày mong muốn",
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.event_outlined),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          child: Text(
                            _preferredDate == null
                                ? "Chọn ngày"
                                : _fmtDate(_preferredDate!),
                            style: const TextStyle(fontSize: 15),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: _buildTimeDropdown()),
                ],
              ),
              const SizedBox(height: 20),

              Center(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.check_circle_outline),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 14),
                  ),
                  onPressed: _submitting ? null : _submit,
                  label: Text(
                    _submitting
                        ? "Đang gửi đăng ký..."
                        : "Xác nhận đăng ký khám",
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: const OutlineInputBorder(),
      ),
    );
  }

  Widget _buildMultilineField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      minLines: 3,
      maxLines: 5,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: const OutlineInputBorder(),
      ),
    );
  }

  Widget _buildTimeDropdown() {
    return DropdownButtonFormField<String>(
      value: _preferredWindow,
      decoration: const InputDecoration(
        labelText: "Khung giờ mong muốn",
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.access_time),
      ),
      items: const [
        DropdownMenuItem(value: "MORNING", child: Text("Sáng (8h–11h30)")),
        DropdownMenuItem(value: "AFTERNOON", child: Text("Chiều (13h30–16h30)")),
        DropdownMenuItem(value: "EVENING", child: Text("Tối (17h30–20h)")),
      ],
      onChanged: (v) => setState(() => _preferredWindow = v),
    );
  }

  String _fmtDate(DateTime d) {
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }
}
