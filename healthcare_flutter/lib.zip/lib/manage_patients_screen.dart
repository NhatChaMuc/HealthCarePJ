// lib/manage_patients_screen.dart
import 'package:flutter/material.dart';
import './api_service.dart';
import './patient.dart';

class ManagePatientsScreen extends StatefulWidget {
  final String token;
  const ManagePatientsScreen({super.key, required this.token});

  @override
  State<ManagePatientsScreen> createState() => _ManagePatientsScreenState();
}

class _ManagePatientsScreenState extends State<ManagePatientsScreen> {
  late ApiService _api;
  late Future<List<Patient>> _future;

  @override
  void initState() {
    super.initState();
    _api = ApiService(token: widget.token);
    _future = _api.getPatients();
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _api.getPatients();
    });
  }

  void _deletePatient(String id) async { // ✅ đổi int -> String
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Xác nhận xoá'),
        content: const Text('Ngài có chắc muốn xoá bệnh nhân này không?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Huỷ')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Xoá')),
        ],
      ),
    );
    if (confirm == true) {
      await _api.deletePatient(id); // ✅ id giờ là String
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Quản lý bệnh nhân')),
      body: FutureBuilder<List<Patient>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: Text('❌ Lỗi: ${snap.error}'));
          }

          final patients = snap.data ?? [];
          if (patients.isEmpty) {
            return const Center(child: Text('Không có bệnh nhân nào.'));
          }

          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView.builder(
              itemCount: patients.length,
              itemBuilder: (context, i) {
                final p = patients[i];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.person)),
                    title: Text(p.fullName),
                    subtitle: Text('${p.phone} • ${p.email}\n${p.address}'),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deletePatient(p.id), // ✅ id là String
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
